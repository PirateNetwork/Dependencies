#[cxx::bridge]
mod ffi {
    enum A {}
}

fn main() {}

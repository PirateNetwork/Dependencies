#[cxx::bridge]
mod ffi {
    struct Monad<T>;

    extern "Haskell" {}
}

fn main() {}

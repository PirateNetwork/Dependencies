Published automatically to https://cxx.rs from master branch.

To build and view locally:

- Install [mdBook]: `cargo install mdbook`.
- Run `mdbook build` in this directory.
- Open the generated *build/index.html*.

[mdBook]: https://github.com/rust-lang/mdBook
